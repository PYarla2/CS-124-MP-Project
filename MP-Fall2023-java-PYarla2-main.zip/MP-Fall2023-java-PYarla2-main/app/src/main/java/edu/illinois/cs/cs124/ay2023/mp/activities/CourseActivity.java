package edu.illinois.cs.cs124.ay2023.mp.activities;

import static edu.illinois.cs.cs124.ay2023.mp.R.id.description;
import static edu.illinois.cs.cs124.ay2023.mp.R.id.rating;
import static edu.illinois.cs.cs124.ay2023.mp.R.id.title;
import static edu.illinois.cs.cs124.ay2023.mp.helpers.Helpers.OBJECT_MAPPER;
import android.content.Intent;
import android.os.Bundle;
import android.widget.RatingBar;
import android.widget.TextView;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import java.util.function.Consumer;
import edu.illinois.cs.cs124.ay2023.mp.R;
import edu.illinois.cs.cs124.ay2023.mp.application.CourseableApplication;
import edu.illinois.cs.cs124.ay2023.mp.helpers.ResultMightThrow;
import edu.illinois.cs.cs124.ay2023.mp.models.Course;
import edu.illinois.cs.cs124.ay2023.mp.models.Rating;
import edu.illinois.cs.cs124.ay2023.mp.models.Summary;

public class CourseActivity extends AppCompatActivity {
  private TextView descriptionTextView;
  private TextView ratingTextView;
  private TextView titleTextView;
  private RatingBar ratingBar;
  /** @noinspection checkstyle:VisibilityModifier, c
   * heckstyle:VisibilityModifier, checkstyle:VisibilityModifier */
  private Summary sums;

  private final Consumer<ResultMightThrow<Course>> courseCallBack =
      (result) -> {
        try {
          Course course = result.getValue();
          runOnUiThread(
              () -> {
                titleTextView.setText(sums.toString());
                descriptionTextView.setText(course.getDescription());

              });
        } catch (Exception e) {
          e.printStackTrace();
        }
      };
  private final Consumer<ResultMightThrow<Rating>> ratingCallBack =
      (result) -> {
        try {
          Rating rat = result.getValue();
          runOnUiThread(
              () -> {
                ratingBar.setRating(rat.getRating());

              });
        } catch (Exception e) {
          e.printStackTrace();
        }
      };

  @Override
  protected void onCreate(@Nullable Bundle x) {
    super.onCreate(x);
    setContentView(R.layout.activity_course);
    descriptionTextView = findViewById(description);
    titleTextView = findViewById(title);
    ratingBar = findViewById(rating);

    Intent intent = getIntent();
    String summary = intent.getStringExtra("summary");
    String rating = intent.getStringExtra("rating");
    try {
      sums = OBJECT_MAPPER.readValue(summary, new TypeReference<>() {});
    } catch (JsonProcessingException e) {
      throw new RuntimeException(e);
    }
    CourseableApplication application = (CourseableApplication) getApplication();
    application.getClient().getCourse(sums, courseCallBack);
    application.getClient().getRating(sums, ratingCallBack);
    runOnUiThread(() -> {
      descriptionTextView.setText("TESTING 123");
      titleTextView.setText(sums.toString());
    });
    ratingBar.setOnRatingBarChangeListener((ratingBarView, ratingFloat, fromUser) -> {
      Rating r = new Rating(sums, ratingFloat);
      application.getClient().postRating(r, (result) -> {});
    });


  }

}
