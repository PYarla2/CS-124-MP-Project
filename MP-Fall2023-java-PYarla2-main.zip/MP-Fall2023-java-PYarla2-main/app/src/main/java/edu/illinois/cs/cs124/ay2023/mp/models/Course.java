package edu.illinois.cs.cs124.ay2023.mp.models;
//Finish
public class Course extends Summary {

  private String description;
  public Course() {


  }
  public String getDescription() {
    return description;
  }
}
