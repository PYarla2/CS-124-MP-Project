package edu.illinois.cs.cs124.ay2023.mp.models;

import androidx.annotation.NonNull;
import org.jetbrains.annotations.NotNull;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
//import java.util.Arrays;

/**
 * Model holding the course summary information shown in the summary list.
 *
 * @noinspection unused
 */
public class Summary implements Comparable<Summary> {
  private String subject;



  /**
   * Get the subject for this Summary.
   *
   * @return the subject for this Summary
   */
  @NotNull
  public final String getSubject() {
    return subject;
  }

  private String number;


  /**
   * Get the number for this Summary.
   *
   * @return the number for this Summary
   */
  @NotNull
  public final String getNumber() {
    return number;
  }

  private String label;

  /**
   * Get the label for this Summary.
   *
   * @return the label for this Summary
   */
  @NotNull
  public final String getLabel() {
    return label;
  }

  /** Create an empty Summary. */
  public Summary() {}

  /**
   * Create a Summary with the provided fields.
   *
   * @param setSubject the department for this Summary
   * @param setNumber the number for this Summary
   * @param setLabel the label for this Summary
   */
  public Summary(@NonNull String setSubject, @NonNull String setNumber, @NotNull String setLabel) {
    subject = setSubject;
    number = setNumber;
    label = setLabel;
  }

  /** {@inheritDoc} */
  @NonNull
  @Override
  public String toString() {
    return subject + " " + number + ": " + label;
  }

  @Override
  public int compareTo(Summary o) {
    int num = Integer.parseInt(number);
    int sNum = Integer.parseInt(o.number);
    if (num < sNum) {
      return -1;
    } else if (num > sNum) {
      return 1;
    }
    return  subject.compareTo(o.subject);
  }
  /** @noinspection checkstyle:Indentation*/
  @NonNull
  public static List<Summary> filter(@NonNull List<Summary> list, @NonNull String filter) {
    String trimmed = filter.trim().toLowerCase();
    List<Summary> temp = new ArrayList<>();
    for (int i = 0; i < list.size(); i++) {
      if (list.get(i).toString().toLowerCase().contains(trimmed)) {
        temp.add(list.get(i));
      }
    }
    Collections.sort(temp);
    temp.sort((first, second) -> {
      return first.toString().toLowerCase().indexOf(trimmed)
          - second.toString().toLowerCase().indexOf(trimmed);
    });
    return temp;
  }
}
